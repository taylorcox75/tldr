# pwdx

> Print working directory of a process.

- Print current working directory of a process:

`pwdx {{process_id}}`
