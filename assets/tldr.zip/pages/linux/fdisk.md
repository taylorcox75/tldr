# fdisk

> A program for managing partition tables and partitions on a hard disk.

- List partitions:

`fdisk -l`

- Start the partition manipulator:

`fdisk {{/dev/sdX}}`
