# runit

> 3-stage init system.

- Start runit's 3-stage init scheme:

`runit`

- Shut down runit:

`kill --CONT {{runit_pid}}`
