# gnome-terminal

> The GNOME Terminal emulator.

- Open a new GNOME terminal window:

`gnome-terminal`

- Run a specific command in a new terminal window:

`gnome-terminal -- {{command}}`

- Open a new tab in the last opened window instead:

`gnome-terminal --tab`

- Set the title of the new tab:

`gnome-terminal --tab --title "{{title}}"`
