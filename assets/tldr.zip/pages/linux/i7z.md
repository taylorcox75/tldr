# i7z

> An Intel CPU (only i3, i5 and i7) realtime reporting tool.

- Start i7z (needs to be run in super user mode):

`sudo i7z`
