# snake4scores

> Show the high scores from the snake4 game.
> More information: <https://manpages.debian.org/snake4/snake4.6.en.html>.

- Show the highscores:

`snake4scores`
