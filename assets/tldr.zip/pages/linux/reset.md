# reset

> Reinitialises the current terminal. Clears the entire terminal screen.

- Reinitialise the current terminal:

`reset`

- Display the terminal type instead:

`reset -q`
