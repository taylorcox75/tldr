# source

> Execute commands from a file in the current shell.

- Evaluate contents of a given file:

`source {{path/to/file}}`
