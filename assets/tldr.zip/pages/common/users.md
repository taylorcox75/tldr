# users

> Display a list of logged in users.

- Display a list of logged in users:

`users`

- Display a list of logged in users according to a specific file:

`users {{/var/log/wmtp}}`
