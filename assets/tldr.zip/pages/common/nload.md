# nload

> A tool for visualizing network usage in the terminal.
> More information: <https://github.com/rolandriegel/nload>.

- View all network traffic (use the arrow keys to switch interfaces):

`nload`

- View network traffic on specific interfaces (use the arrow keys to switch interfaces):

`nload device {{interface_one}} {{interface_two}}`
