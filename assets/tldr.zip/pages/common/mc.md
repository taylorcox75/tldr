# mc

> Midnight Commander, a terminal based file manager.
> Navigate the directory structure using the arrow keys, the mouse or by typing the commands into the terminal.
> More information: <https://midnight-commander.org>.

- Start `mc`:

`mc`

- Start `mc` in black and white:

`mc -b`
